"""Layer 3 · 规划执行层 (Planning & Execution)

短程规划：用转移表 + 目标假设做 BFS/A*，不开 LLM。
长程规划：当短程搜索失效 / 目标模糊 / 新关卡时，才触发 LLM（由 Agent 层节制）。
LLM 调用节制：每关硬预算，直接回应"纯 LLM 烧 token"的失败模式。
"""
from ..core import SoloConfig, Logger, clamp


class LightweightPlanner:
    """无 LLM 的短程规划：基于转移表的贪心 + 有限 BFS。

    当世界模型场已积累足够转移时，用它做局部搜索；
    否则退化为 ExplorationEngine 的信息增益评分。
    """
    def __init__(self, cfg: SoloConfig, field, logger: Logger = None):
        self.cfg = cfg
        self.field = field
        self.log = logger or Logger()

    def search(self, goal_hint=None, depth=None) -> str:
        """有限深度 BFS：在转移图上从当前状态向目标搜索。

        返回下一步动作；搜索失败返回 None（上层应降级为探索/反思）。
        """
        depth = depth or self.cfg.lightweight_search_depth
        # 若转移表为空（全新关卡），无法搜索 → 返回 None
        if len(self.field.transition_table) == 0:
            return None
        # 占位：真实实现在此做 (state, action) 图的 BFS，
        # 用 goal_hint 评估叶子节点贴近度。为保持框架可跑，此处返回 None。
        return None

    def greedy_next(self, scored_actions: list) -> str:
        """转移表不足时的贪心：直接取探索评分最高的动作。"""
        if not scored_actions:
            return None
        return scored_actions[0][0]


class LLMPlanner:
    """LLM 战略顾问：仅做"战略重估"，不做微观决策。

    通过 inject_llm() 注入调用函数，保持框架对具体模型解耦，
    便于本地/评测环境切换（评测期无网络，可用规则化 fallback）。
    """
    def __init__(self, cfg: SoloConfig, logger: Logger = None):
        self.cfg = cfg
        self.log = logger or Logger()
        self._llm_fn = None
        self.calls_used = 0

    def inject_llm(self, llm_fn):
        """注入 LLM 调用函数：fn(field_snapshot, valid_actions) -> action_str"""
        self._llm_fn = llm_fn

    @property
    def budget_left(self) -> int:
        return self.cfg.llm_calls_per_game - self.calls_used

    def can_call(self) -> bool:
        return self._llm_fn is not None and self.budget_left > 0

    def plan(self, snapshot, valid_actions) -> str:
        """调用 LLM 做战略决策，自动计入预算。"""
        if not self.can_call():
            return None
        self.calls_used += 1
        self.log.log("LLM", f"call #{self.calls_used}/{self.cfg.llm_calls_per_game}")
        try:
            return self._llm_fn(snapshot, valid_actions)
        except Exception as e:
            self.log.log("LLM", f"error: {e}")
            return None
